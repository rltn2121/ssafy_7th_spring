package com.ssafy.word;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordCloud2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
